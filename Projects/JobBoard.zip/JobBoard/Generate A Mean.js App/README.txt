--In order to run the app, install the dependencies first with...

npm install

--Then run the app with

grunt
