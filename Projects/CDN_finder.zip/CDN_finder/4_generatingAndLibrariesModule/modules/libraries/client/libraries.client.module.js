(function (app) {
  'use strict';

  app.registerModule('libraries');
}(ApplicationConfiguration));
